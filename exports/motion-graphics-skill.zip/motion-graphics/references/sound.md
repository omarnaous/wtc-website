# Sound design

`scripts/sound.py cues.json out.wav` mixes synthesized cues into a 48 kHz stereo WAV, soft-clips and normalizes to -1 dBFS. Everything is generated from noise and oscillators, so it is royalty-free.

## cues.json

```json
{
  "fps": 30, "duration": 8.0, "seed": 7,
  "cues": [
    { "type": "tick",   "frame": 10, "gain": 0.18 },
    { "type": "riser",  "start": 21, "end": 80, "gain": 0.6 },
    { "type": "impact", "frame": 84, "gain": 0.95 },
    { "type": "chime",  "frame": 112, "gain": 0.22, "pan": 0.25 },
    { "type": "whoosh", "frame": 126, "gain": 0.1 },
    { "type": "pad",    "start": 84, "gain": 0.07, "chord": [110, 164.8, 220, 277.2, 329.6] },
    { "type": "glint",  "frame": 170, "gain": 0.06 },
    { "type": "beat",   "start": 0, "end": 360, "bpm": 120, "pattern": "four-on-floor", "gain": 0.5 }
  ]
}
```

Cue types and when to use them (match each scene's subject: printers for receipts, coins for money, clicks for UI):
| type | sound | use for |
|---|---|---|
| `tick` | short glassy click | something small appearing, a spark, a cursor |
| `riser` | swept noise + gliding tone, cut dead at `end` | tension before a hit (end it 3-6 frames before the hit) |
| `impact` | sub drop + punch + crack + reverb boom | the main hit / logo landing |
| `chime` | bright bell with long shimmer | a detail landing, a reveal, success |
| `whoosh` | airy band-passed swell | text sliding in, transitions, camera moves |
| `pad` | soft chord bed (`chord` in Hz), fades in | under holds and end frames |
| `glint` | faint high sparkle | sheens, highlights |
| `drone` | low evolving bed | loops, dark openings, 3D scenes |
| `kick` / `snare` / `hat` | single drum hits | accenting individual words or cuts |
| `beat` | full pattern at `bpm` (`four-on-floor`, `half-time`, `trap`) | kinetic type, showreels, data stories |
| `printer` | dot-matrix needle clicks + motor (`start`/`end`, `rate`, `line`) | receipts, invoices, printing anything |
| `coin` | metallic ping (`freq`, raise it for rising sequences) | money counting up, bars growing |
| `register` | cash-register clack + ching + coin rattle | prices, savings, "sold" moments |
| `cash` | banknote snap, no ring | a price drops, money saved, a "paid" moment |
| `cash_count` | bills flicking between `start`/`end` (`rate`) | a money counter ticking up |
| `blip` | soft rounded data tick (`freq`, step it up) | chart bars or points appearing |
| `sweep` | soft tone gliding `f0`→`f1` between `start`/`end` | a chart line drawing |
| `swish` | paper swish (start/end): rising band-passed air with paper flutter | a card or print flying in; end it on the landing frame |
| `slap` | a card slapped onto a table: papery crack + soft thump | the frame a card lands (pair with `swish`); the tactile alternative to whooshes and impacts |
| `clink` | ice cube into a glass: bright inharmonic ping + tiny thud (`pitch`) | ASMR drink shots, one per cube |
| `pour` | liquid pouring (start/end): filtered noise whose pitch rises as it fills, with gurgles | coffee/drinks filling a cup |
| `sting` | dramatic 'dun dun DUNNN': two brass stabs and a held diminished chord with timpani (`step`, `hold`) | the meme crash-zoom ("emotional damage"), once per reel |
| `vine_boom` | deep saturated sub thump (the viral meme boom) | one punchline or shocking number, max 1-2 per reel |
| `scratch` | record scratch | the 'wait, what?' turn |
| `bass_drop` | 808 slide down | the big reveal / title slam |
| `stamp` | thud + slap | stamps, seals, 'PAID' |
| `buzz` | 'wrong answer' buzzer | a price or bad option getting crossed out |
| `coin_drop` | one coin bouncing on a table (`freq`) | a small price is said or shown |
| `coins` | a handful of coins landing (`count`, `dur`) | a bigger amount, savings, a payout |
| `cash_riffle` | bill-counter machine 'brrrt' (`dur`, `rate`) | a large sum is said or a total lands |
| `graph_tick` | infographic tick (`freq`, step it up per bar) | each bar/point appearing on a chart |
| `graph_rise` | rising tone + speeding ticks between `start`/`end` (`f0`, `f1`) | a line graph drawing |
| `counter` | ticks that slow as the number settles, `start`/`end` | a number counting up |
| `lofi` | lo-fi hip-hop groove: EP chords, round bass, soft swung drums, vinyl crackle (`bpm` ~85-100, `lp` ~900 for a muffled intro, `drums`/`keys`/`bass` 0..1) | the bed under a voice-over reel; split it into sections (muffled problem, drop out for the turn, full groove for the solution) |
| `rip` | paper tear (`start`/`end` or `dur`) | paper transitions, tearing a bill |
| `glitch` | digital stutter (`dur`) | crossing something out, errors, cuts |
| `click` / `pop` | UI tap / bubbly pop | toggles, buttons, cards popping in |
| `typing` | keyboard clicks over `start`/`end` | code typing, text fields |

## Warmth

If the mix sounds sharp or tiring ("too bright", "hurts the ears"), set `"lowpass": 4500` at the top of cues.json, give `beat` cues `"hats": 0.1` or less, drop `glint`/`glitch`, swap bell-like `register`/`coin`/`chime` for `cash`, `cash_count` and `blip`, and pitch `chime`, `coin`, `tick` and `click` down with `freq` (chime 660-880, coin 800-1200, tick ~1200, click ~600). Under a voice-over, keep the bed warm and low so the voice owns the 2-5 kHz range.

## Levels

Impact around 0.9-1.0, riser 0.5-0.6, beat 0.4-0.6, chime 0.2, whoosh 0.1, pad 0.05-0.08, glint 0.05. The mix is normalized after summing, so these are relative. Pan small details (±0.2-0.5) and keep hits centered.

## Beat grid

`python3 sound.py --grid --bpm 120 --fps 30 --bars 6` prints the frame of every beat. Put word or cut changes on those frames (store them in `timing.js`). 120 BPM = 15 frames per beat at 30 fps, which is comfortable for word-per-beat kinetic type. Use 100 BPM (18 frames) for calmer lines and 140 BPM (12.86 frames, round per beat) for frantic ones.

## Loops

For seamless loops set `"loop": true` at the top level. `sound.py` then snaps pad and drone frequencies to whole cycles per loop, filters noise circularly, and wraps anything that rings past the end back onto the start, so the audio is periodic by construction. Use `drone`/`pad` spanning the whole duration plus hits placed on the beat grid.

For social reels with a voice-over: business explainer reels typically sit on lo-fi hip-hop or a funky groove (85-110 BPM, no lead melody) so the voice stays clear; use `lofi` for that, and a handful of hits only where something happens on screen (vine_boom, scratch, bass_drop, stamp, whoosh). Leave the music to the platform's trending-audio library at low volume; it is licensed there and boosts reach.

## Music beds: pick a genre synthesis can do honestly

Synthesis sounds fake when it imitates acoustic instruments, so choose a bed whose real instruments are synths anyway:
- `house`: 120 BPM tech-house (909-style kick, clap, closed/open hats, offbeat saw bass, sidechained supersaw stabs, pad).
  `"sections": [[frame, "intro"|"gap"|"drop"|"break"|"outro"], ...]` switches layers in and out (absolute frames);
  `"lp_auto": [[frame, Hz], ...]` automates a low-pass (muffled intro that opens on the drop). One chord per bar:
  Am, F, C, G (A minor). Best default for promos and "watch it build" ads.
- `lofi_tape`: 80 BPM tape lo-fi (FM Rhodes ii-V-I-VI, swung boom-bap, wow/flutter, vinyl, sidechain), `lp_auto`,
  `"stop": [a, b]` for a tape stop. Calmer; at 80 BPM a 45-frame cut is exactly 2 beats.
- `lofi`: the older, simpler lo-fi bed.
Whatever the bed, also deliver a "NoMusic" mix (effects only) so the user can add trending audio in-app.

## Transitions and real samples

- `swoosh` (start/end, "peak" 0..1, "f" pass frequency): a doppler pass-by. Vary "f" per cut so ten cuts don't repeat.
- `reverse_swell` (start/end, "notes"): reversed cymbal + chord tail swelling INTO a cut; use chord tones of the next bar.
- `thump` (frame, "freq"): soft sub landing under a cut or hit.
- `sample` (frame, "file", "gain", "rate", "trim", "lp"): any real audio file (wav/mp3/ogg via ffmpeg). The skill ships
  CC0 UI sounds in `assets/sfx/` (see its README for which notes each one plays).

## Tuning (the "broken piano" problem)

A tonal effect that is off the music's pitch grid sounds broken even when it is quiet. Before using any tonal sample
under music, measure its pitch (FFT peaks in cents vs A440); reject packs that are consistently off (uisfx "glass" is
~+45 cents), and shift kept ones only by whole semitones (`rate = 2 ** (n/12)`) into the chord of the bar they land on.
Never randomise the rate of a tonal sound (fine for noise-like clicks and typing).

## Master level

The spec takes `"peak_db"` (default -1). -3 gives about -15/-16 LUFS for a busy promo, close to what Instagram plays at;
users often find -1 dBFS mixes too loud. Keep UI effects about 3 dB under the bed.
